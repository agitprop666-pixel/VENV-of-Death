"""
VENV of Death
Death's Head Software

Python virtual environment manager: discover/create venvs, install/uninstall
pip packages, drag-and-drop script execution, integrated console.
"""

from __future__ import annotations

import json
import shlex
import shutil
import sys
import time
from pathlib import Path
from typing import List, Optional

from PyQt6.QtCore import (
    Qt, QProcess, QProcessEnvironment, QSettings, QTimer, pyqtSignal,
)
from PyQt6.QtGui import (
    QColor, QDragEnterEvent, QDropEvent, QFont, QIcon, QPainter, QPixmap,
    QTextCharFormat, QTextCursor,
)
from PyQt6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QFileDialog,
    QFrame, QGroupBox, QHBoxLayout, QHeaderView, QInputDialog, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton,
    QSizePolicy, QSplashScreen, QSplitter, QStatusBar, QTableWidget,
    QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)


# =============================================================================
# Global Definitions
# =============================================================================

APP_NAME = "VENV of Death"
ORG_NAME = "Death's Head Software"


# =============================================================================
# Splash Screen
# =============================================================================

def create_splash():
    """
    Creates the QSplashScreen.

    It first checks for an external 'splash.png'. If not found, it generates
    a dark screen with the app name, org name, and ASCII skull art.
    """
    try:
        splash_path = Path(__file__).parent / "splash.png"

        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art): painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 50); footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


# =============================================================================
# Icon
# =============================================================================

def create_icon():
    """
    Returns the application QIcon.

    Looks for icon.png or icon.ico in the script directory first, then falls
    back to splash.png if present. If none exist, generates a simple skull
    procedurally so the taskbar/title bar always has something on-brand.
    """
    try:
        base = Path(__file__).parent
        for name in ("icon.png", "icon.ico", "splash.png"):
            path = base / name
            if path.exists():
                return QIcon(str(path))

        # Fallback: simple white skull on dark background
        pixmap = QPixmap(256, 256)
        pixmap.fill(QColor(20, 20, 20))
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(240, 240, 240))
        # Cranium
        painter.drawEllipse(56, 44, 144, 140)
        # Jaw
        painter.drawRect(86, 160, 84, 52)
        # Cut out eye sockets and nasal cavity
        painter.setBrush(QColor(20, 20, 20))
        painter.drawEllipse(82, 92, 42, 44)
        painter.drawEllipse(132, 92, 42, 44)
        painter.drawEllipse(118, 138, 20, 24)
        # Teeth gaps
        for i in range(5):
            x = 96 + i * 14
            painter.drawRect(x, 178, 4, 26)
        painter.end()
        return QIcon(pixmap)
    except Exception as e:
        print("Icon error:", e)
        return None


# =============================================================================
# Constants
# =============================================================================

VENV_SEARCH_PATHS = [
    Path.home() / ".venvs",
    Path.home() / "venvs",
    Path.home() / ".virtualenvs",
    Path.home() / "Documents",
    Path.home() / "Projects",
    Path.home() / "Development",
    Path.home() / "code",
    Path.home() / "src",
]


# =============================================================================
# Theming
# =============================================================================

DARK_STYLESHEET = """
QMainWindow, QWidget { background-color: #141414; color: #e0e0e0; }

QLabel { color: #e0e0e0; }

QPushButton {
    background-color: #2a2a2a;
    color: #e0e0e0;
    border: 1px solid #3a3a3a;
    border-radius: 3px;
    padding: 6px 12px;
    min-height: 18px;
}
QPushButton:hover { background-color: #3a3a3a; border-color: #5a5a5a; }
QPushButton:pressed { background-color: #1a1a1a; }
QPushButton:disabled {
    background-color: #1a1a1a; color: #555555; border-color: #2a2a2a;
}
QPushButton#dangerButton { background-color: #3a1a1a; border-color: #6a2a2a; }
QPushButton#dangerButton:hover { background-color: #5a2a2a; border-color: #8a3a3a; }
QPushButton#primaryButton { background-color: #1a3a1a; border-color: #2a6a2a; }
QPushButton#primaryButton:hover { background-color: #2a5a2a; border-color: #3a8a3a; }

QLineEdit, QComboBox {
    background-color: #1a1a1a;
    color: #e0e0e0;
    border: 1px solid #3a3a3a;
    border-radius: 3px;
    padding: 5px 8px;
    selection-background-color: #4a4a4a;
}
QLineEdit:focus, QComboBox:focus { border-color: #6a6a6a; }
QComboBox::drop-down { border: none; width: 20px; }
QComboBox::down-arrow {
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid #a0a0a0;
    margin-right: 6px;
}
QComboBox QAbstractItemView {
    background-color: #1a1a1a;
    color: #e0e0e0;
    border: 1px solid #3a3a3a;
    selection-background-color: #3a3a3a;
}

QPlainTextEdit, QTextEdit {
    background-color: #0a0a0a;
    color: #d0d0d0;
    border: 1px solid #2a2a2a;
    font-family: "Courier New", monospace;
    selection-background-color: #4a4a4a;
}

QTableWidget {
    background-color: #0f0f0f;
    color: #e0e0e0;
    border: 1px solid #2a2a2a;
    gridline-color: #2a2a2a;
    selection-background-color: #3a3a3a;
}
QTableWidget::item { padding: 4px; }
QTableWidget::item:selected { background-color: #3a3a3a; color: #ffffff; }

QHeaderView::section {
    background-color: #1f1f1f;
    color: #e0e0e0;
    border: none;
    border-right: 1px solid #2a2a2a;
    border-bottom: 1px solid #2a2a2a;
    padding: 6px;
    font-weight: bold;
}

QTabWidget::pane { background-color: #141414; border: 1px solid #2a2a2a; border-top: none; }
QTabBar::tab {
    background-color: #1a1a1a;
    color: #a0a0a0;
    border: 1px solid #2a2a2a;
    padding: 8px 16px;
    margin-right: 2px;
}
QTabBar::tab:selected { background-color: #2a2a2a; color: #ffffff; border-bottom-color: #2a2a2a; }
QTabBar::tab:hover:!selected { background-color: #252525; }

QGroupBox {
    border: 1px solid #2a2a2a;
    border-radius: 4px;
    margin-top: 12px;
    padding-top: 8px;
    color: #e0e0e0;
    font-weight: bold;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    padding: 0 5px;
    background-color: #141414;
}

QStatusBar { background-color: #0f0f0f; color: #a0a0a0; border-top: 1px solid #2a2a2a; }
QStatusBar::item { border: none; }

QScrollBar:vertical { background: #1a1a1a; width: 12px; border: none; }
QScrollBar::handle:vertical { background: #3a3a3a; min-height: 20px; border-radius: 3px; }
QScrollBar::handle:vertical:hover { background: #4a4a4a; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: #1a1a1a; height: 12px; border: none; }
QScrollBar::handle:horizontal { background: #3a3a3a; min-width: 20px; border-radius: 3px; }
QScrollBar::handle:horizontal:hover { background: #4a4a4a; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }

QSplitter::handle { background-color: #2a2a2a; }
QSplitter::handle:horizontal { width: 3px; }
QSplitter::handle:vertical { height: 3px; }

QFrame#dropZone { background-color: #1a1a1a; border: 2px dashed #3a3a3a; border-radius: 6px; }
QFrame#dropZoneActive { background-color: #2a3a2a; border: 2px dashed #5a8a5a; border-radius: 6px; }

QCheckBox { color: #e0e0e0; spacing: 6px; }
QCheckBox::indicator {
    width: 14px; height: 14px;
    background-color: #1a1a1a;
    border: 1px solid #3a3a3a;
    border-radius: 2px;
}
QCheckBox::indicator:checked { background-color: #3a6a3a; border-color: #5a8a5a; }
"""


# =============================================================================
# Venv discovery and management
# =============================================================================

class VenvManager:
    """Discovery and validation of Python virtual environments."""

    @staticmethod
    def is_valid_venv(path: Path) -> bool:
        if not path.is_dir():
            return False
        if not (path / "pyvenv.cfg").is_file():
            return False
        if sys.platform == "win32":
            return (path / "Scripts" / "python.exe").is_file()
        return ((path / "bin" / "python").is_file()
                or (path / "bin" / "python3").is_file())

    @staticmethod
    def get_python(venv_path: Path) -> Optional[Path]:
        if sys.platform == "win32":
            p = venv_path / "Scripts" / "python.exe"
            return p if p.is_file() else None
        for name in ("python", "python3"):
            p = venv_path / "bin" / name
            if p.is_file():
                return p
        return None

    @staticmethod
    def discover() -> List[Path]:
        """Discover virtual environments in common locations."""
        found: List[Path] = []
        seen: set = set()

        for base in VENV_SEARCH_PATHS:
            if not base.exists():
                continue
            try:
                for child in base.iterdir():
                    if not child.is_dir():
                        continue
                    if VenvManager.is_valid_venv(child):
                        resolved = child.resolve()
                        if resolved not in seen:
                            seen.add(resolved)
                            found.append(child)
                    else:
                        # Check one level deeper for project/<venv> pattern
                        for sub_name in ("venv", ".venv", "env", ".env"):
                            sub = child / sub_name
                            if VenvManager.is_valid_venv(sub):
                                resolved = sub.resolve()
                                if resolved not in seen:
                                    seen.add(resolved)
                                    found.append(sub)
            except (PermissionError, OSError):
                continue

        return sorted(found, key=lambda p: str(p).lower())


# =============================================================================
# Console
# =============================================================================

class Console(QPlainTextEdit):
    """Read-only console with colored output channels."""

    COLOR_STDOUT = QColor("#d0d0d0")
    COLOR_STDERR = QColor("#ff6b6b")
    COLOR_SYSTEM = QColor("#6bcfff")
    COLOR_CMD = QColor("#a0e87b")
    COLOR_SUCCESS = QColor("#7be887")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setMaximumBlockCount(5000)
        font = QFont("Courier New", 10)
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.setFont(font)

    def _append(self, text: str, color: QColor):
        if not text:
            return
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        fmt = QTextCharFormat()
        fmt.setForeground(color)
        cursor.setCharFormat(fmt)
        cursor.insertText(text)
        self.setTextCursor(cursor)
        self.ensureCursorVisible()

    def write_stdout(self, text: str):
        self._append(text, self.COLOR_STDOUT)

    def write_stderr(self, text: str):
        self._append(text, self.COLOR_STDERR)

    def write_system(self, text: str):
        if not text.endswith("\n"):
            text += "\n"
        self._append(text, self.COLOR_SYSTEM)

    def write_command(self, cmd: str):
        self._append(f"\n$ {cmd}\n", self.COLOR_CMD)

    def write_success(self, text: str):
        if not text.endswith("\n"):
            text += "\n"
        self._append(text, self.COLOR_SUCCESS)


# =============================================================================
# Process runners
# =============================================================================

class ProcessRunner(QWidget):
    """QProcess wrapper with signals for console integration."""

    started = pyqtSignal(str)
    stdout = pyqtSignal(str)
    stderr = pyqtSignal(str)
    finished = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._proc: Optional[QProcess] = None

    def is_running(self) -> bool:
        return (self._proc is not None
                and self._proc.state() != QProcess.ProcessState.NotRunning)

    def run(self, program: str, args: List[str], cwd: Optional[str] = None) -> bool:
        if self.is_running():
            return False

        self._proc = QProcess(self)
        self._proc.setProcessChannelMode(QProcess.ProcessChannelMode.SeparateChannels)
        if cwd:
            self._proc.setWorkingDirectory(cwd)

        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONUNBUFFERED", "1")
        env.insert("PYTHONIOENCODING", "utf-8")
        self._proc.setProcessEnvironment(env)

        self._proc.readyReadStandardOutput.connect(self._on_stdout)
        self._proc.readyReadStandardError.connect(self._on_stderr)
        self._proc.finished.connect(self._on_finished)
        self._proc.errorOccurred.connect(self._on_error)

        cmd_str = program + " " + " ".join(shlex.quote(a) for a in args)
        self.started.emit(cmd_str)
        self._proc.start(program, args)
        return True

    def stop(self):
        if not self.is_running():
            return
        self._proc.terminate()
        if not self._proc.waitForFinished(3000):
            self._proc.kill()

    def _on_stdout(self):
        if not self._proc:
            return
        data = bytes(self._proc.readAllStandardOutput()).decode("utf-8", errors="replace")
        self.stdout.emit(data)

    def _on_stderr(self):
        if not self._proc:
            return
        data = bytes(self._proc.readAllStandardError()).decode("utf-8", errors="replace")
        self.stderr.emit(data)

    def _on_finished(self, exit_code: int, _exit_status):
        self.finished.emit(exit_code)
        self._proc = None

    def _on_error(self, error):
        self.stderr.emit(f"\n[process error: {error}]\n")


class QueryRunner(QWidget):
    """Runs a process silently and returns its full output."""

    completed = pyqtSignal(int, str, str)  # exit_code, stdout, stderr

    def __init__(self, parent=None):
        super().__init__(parent)
        self._proc: Optional[QProcess] = None
        self._stdout_buf = ""
        self._stderr_buf = ""

    def is_running(self) -> bool:
        return (self._proc is not None
                and self._proc.state() != QProcess.ProcessState.NotRunning)

    def run(self, program: str, args: List[str]) -> bool:
        if self.is_running():
            return False
        self._stdout_buf = ""
        self._stderr_buf = ""
        self._proc = QProcess(self)
        self._proc.setProcessChannelMode(QProcess.ProcessChannelMode.SeparateChannels)
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONIOENCODING", "utf-8")
        self._proc.setProcessEnvironment(env)
        self._proc.readyReadStandardOutput.connect(self._on_stdout)
        self._proc.readyReadStandardError.connect(self._on_stderr)
        self._proc.finished.connect(self._on_finished)
        self._proc.start(program, args)
        return True

    def _on_stdout(self):
        if not self._proc:
            return
        self._stdout_buf += bytes(self._proc.readAllStandardOutput()).decode("utf-8", errors="replace")

    def _on_stderr(self):
        if not self._proc:
            return
        self._stderr_buf += bytes(self._proc.readAllStandardError()).decode("utf-8", errors="replace")

    def _on_finished(self, exit_code: int, _exit_status):
        self.completed.emit(exit_code, self._stdout_buf, self._stderr_buf)
        self._proc = None


# =============================================================================
# Drop zone
# =============================================================================

class ScriptDropZone(QFrame):
    """Drag-and-drop area for Python scripts."""

    file_dropped = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("dropZone")
        self.setAcceptDrops(True)
        self.setMinimumHeight(120)
        self.setFrameShape(QFrame.Shape.StyledPanel)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        self.label = QLabel("Drop a .py script here\n\nor click Browse below")
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("color: #808080; font-size: 14px;")
        layout.addWidget(self.label)

    def set_file(self, path: str):
        self.label.setText(f"Loaded:\n{path}")
        self.label.setStyleSheet(
            "color: #b0e0b0; font-size: 12px; font-family: 'Courier New', monospace;"
        )

    def clear_file(self):
        self.label.setText("Drop a .py script here\n\nor click Browse below")
        self.label.setStyleSheet("color: #808080; font-size: 14px;")

    def _refresh_style(self):
        self.style().unpolish(self)
        self.style().polish(self)

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if urls and urls[0].toLocalFile().endswith(".py"):
                event.acceptProposedAction()
                self.setObjectName("dropZoneActive")
                self._refresh_style()
                return
        event.ignore()

    def dragLeaveEvent(self, _event):
        self.setObjectName("dropZone")
        self._refresh_style()

    def dropEvent(self, event: QDropEvent):
        urls = event.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if path.endswith(".py"):
                self.file_dropped.emit(path)
                event.acceptProposedAction()
        self.setObjectName("dropZone")
        self._refresh_style()


# =============================================================================
# Main Window
# =============================================================================

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1100, 750)

        self.current_venv: Optional[Path] = None
        self.current_script: Optional[Path] = None
        self._last_op: Optional[str] = None
        self._pending_venv_after_create: Optional[Path] = None
        self._pending_freeze_path: Optional[str] = None

        self.runner = ProcessRunner(self)
        self.query = QueryRunner(self)
        self.settings = QSettings()

        self._build_ui()
        self._wire_signals()
        self._load_saved_venv()

    # ---- UI construction ----

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        # Venv selector
        venv_box = QGroupBox("Virtual Environment")
        venv_layout = QVBoxLayout(venv_box)
        venv_layout.setSpacing(6)

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Active:"))
        self.venv_label = QLabel("(none selected)")
        self.venv_label.setStyleSheet(
            "color: #b0e0b0; font-family: 'Courier New', monospace;"
        )
        self.venv_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        row1.addWidget(self.venv_label, 1)

        self.btn_browse = QPushButton("Browse...")
        self.btn_browse.setToolTip("Select an existing virtual environment")
        self.btn_create = QPushButton("Create New")
        self.btn_create.setToolTip("Create a new virtual environment")
        self.btn_create.setObjectName("primaryButton")
        row1.addWidget(self.btn_browse)
        row1.addWidget(self.btn_create)
        venv_layout.addLayout(row1)

        self.venv_info = QLabel("No venv selected")
        self.venv_info.setStyleSheet(
            "color: #808080; font-family: 'Courier New', monospace; font-size: 11px;"
        )
        venv_layout.addWidget(self.venv_info)
        root.addWidget(venv_box)

        # Splitter: tabs (top) | console (bottom)
        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.setChildrenCollapsible(False)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_packages_tab(), "Packages")
        self.tabs.addTab(self._build_scripts_tab(), "Scripts")
        splitter.addWidget(self.tabs)

        console_box = QGroupBox("Console")
        console_layout = QVBoxLayout(console_box)
        console_layout.setSpacing(6)
        self.console = Console()
        console_layout.addWidget(self.console)

        console_buttons = QHBoxLayout()
        self.btn_clear_console = QPushButton("Clear")
        self.btn_stop = QPushButton("Stop")
        self.btn_stop.setObjectName("dangerButton")
        self.btn_stop.setEnabled(False)
        console_buttons.addStretch()
        console_buttons.addWidget(self.btn_clear_console)
        console_buttons.addWidget(self.btn_stop)
        console_layout.addLayout(console_buttons)
        splitter.addWidget(console_box)

        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        splitter.setSizes([400, 280])
        root.addWidget(splitter, 1)

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("Ready")

    def _build_packages_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(8)

        # Install row
        install_row = QHBoxLayout()
        install_row.addWidget(QLabel("Install:"))
        self.install_input = QLineEdit()
        self.install_input.setPlaceholderText(
            "package spec (e.g. requests, requests==2.31.0, numpy>=1.20, git+https://...)"
        )
        install_row.addWidget(self.install_input, 1)
        self.btn_install = QPushButton("Install")
        self.btn_install.setObjectName("primaryButton")
        install_row.addWidget(self.btn_install)
        layout.addLayout(install_row)

        # Package table
        self.pkg_table = QTableWidget(0, 2)
        self.pkg_table.setHorizontalHeaderLabels(["Package", "Version"])
        self.pkg_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.pkg_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.pkg_table.verticalHeader().setVisible(False)
        self.pkg_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.pkg_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.pkg_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        layout.addWidget(self.pkg_table, 1)

        # Action row
        action_row = QHBoxLayout()
        self.pkg_count_label = QLabel("0 packages")
        self.pkg_count_label.setStyleSheet("color: #808080;")
        action_row.addWidget(self.pkg_count_label)
        action_row.addStretch()
        self.btn_refresh_pkgs = QPushButton("Refresh List")
        self.btn_upgrade = QPushButton("Upgrade Selected")
        self.btn_uninstall = QPushButton("Uninstall Selected")
        self.btn_uninstall.setObjectName("dangerButton")
        self.btn_freeze = QPushButton("Freeze to file...")
        action_row.addWidget(self.btn_refresh_pkgs)
        action_row.addWidget(self.btn_upgrade)
        action_row.addWidget(self.btn_uninstall)
        action_row.addWidget(self.btn_freeze)
        layout.addLayout(action_row)

        return w

    def _build_scripts_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(8)

        self.drop_zone = ScriptDropZone()
        layout.addWidget(self.drop_zone)

        args_row = QHBoxLayout()
        args_row.addWidget(QLabel("Args:"))
        self.args_input = QLineEdit()
        self.args_input.setPlaceholderText(
            "optional command-line arguments passed to the script"
        )
        args_row.addWidget(self.args_input, 1)
        layout.addLayout(args_row)

        self.cwd_check = QCheckBox("Run from script's directory")
        self.cwd_check.setChecked(True)
        layout.addWidget(self.cwd_check)

        action_row = QHBoxLayout()
        self.btn_browse_script = QPushButton("Browse...")
        self.btn_clear_script = QPushButton("Clear")
        self.btn_run_script = QPushButton("Run Script")
        self.btn_run_script.setObjectName("primaryButton")
        self.btn_run_script.setEnabled(False)
        action_row.addWidget(self.btn_browse_script)
        action_row.addWidget(self.btn_clear_script)
        action_row.addStretch()
        action_row.addWidget(self.btn_run_script)
        layout.addLayout(action_row)

        layout.addStretch()
        return w

    # ---- Wiring ----

    def _wire_signals(self):
        self.btn_browse.clicked.connect(self.browse_venv)
        self.btn_create.clicked.connect(self.create_venv)

        self.btn_install.clicked.connect(self.install_package)
        self.install_input.returnPressed.connect(self.install_package)
        self.btn_refresh_pkgs.clicked.connect(self.refresh_packages)
        self.btn_upgrade.clicked.connect(self.upgrade_selected)
        self.btn_uninstall.clicked.connect(self.uninstall_selected)
        self.btn_freeze.clicked.connect(self.freeze_packages)

        self.drop_zone.file_dropped.connect(self.set_script)
        self.btn_browse_script.clicked.connect(self.browse_script)
        self.btn_clear_script.clicked.connect(self.clear_script)
        self.btn_run_script.clicked.connect(self.run_script)

        self.btn_clear_console.clicked.connect(self.console.clear)
        self.btn_stop.clicked.connect(self.stop_process)

        self.runner.started.connect(self._on_runner_started)
        self.runner.stdout.connect(self.console.write_stdout)
        self.runner.stderr.connect(self.console.write_stderr)
        self.runner.finished.connect(self._on_runner_finished)

        self.query.completed.connect(self._on_query_completed)

    # ---- Venv selection ----

    @staticmethod
    def _venv_display_name(path: Path) -> str:
        try:
            rel = path.relative_to(Path.home())
            return f"~/{rel}"
        except ValueError:
            return str(path)

    def _load_saved_venv(self):
        """Load the venv saved from the previous session, if it still exists."""
        saved = self.settings.value("last_venv", "", type=str)
        if not saved:
            return
        saved_path = Path(saved)
        if not VenvManager.is_valid_venv(saved_path):
            return
        self._set_current_venv(saved_path)

    def browse_venv(self):
        directory = QFileDialog.getExistingDirectory(
            self, "Select virtual environment directory",
            str(Path.home()), QFileDialog.Option.ShowDirsOnly,
        )
        if not directory:
            return
        path = Path(directory)
        if not VenvManager.is_valid_venv(path):
            QMessageBox.warning(
                self, "Invalid venv",
                "The selected directory does not appear to be a Python "
                "virtual environment.\n\n(no pyvenv.cfg or python executable found)",
            )
            return
        self._set_current_venv(path)

    def create_venv(self):
        default_parent = Path.home() / ".venvs"
        if not default_parent.exists():
            default_parent = Path.home()
        directory = QFileDialog.getExistingDirectory(
            self, "Select directory to create venv in",
            str(default_parent), QFileDialog.Option.ShowDirsOnly,
        )
        if not directory:
            return
        name, ok = QInputDialog.getText(
            self, "Create venv", "Venv name:", QLineEdit.EchoMode.Normal, "myenv",
        )
        if not ok or not name.strip():
            return
        target = Path(directory) / name.strip()
        if target.exists():
            QMessageBox.warning(self, "Path exists", f"{target} already exists.")
            return

        python_bin = shutil.which("python3") or shutil.which("python") or sys.executable
        self.console.write_system(f"Creating venv at {target}")
        self._pending_venv_after_create = target
        self._last_op = "venv_create"
        self.runner.run(python_bin, ["-m", "venv", str(target)])

    def _set_current_venv(self, path: Optional[Path]):
        """Set the active venv and sync all dependent UI state."""
        self.current_venv = path
        self.settings.setValue("last_venv", str(path) if path else "")

        if path:
            self.venv_label.setText(self._venv_display_name(path))
            py = VenvManager.get_python(path)
            self.venv_info.setText(f"Python: {py}" if py else f"Path: {path}")
        else:
            self.venv_label.setText("(none selected)")
            self.venv_info.setText("No venv selected")

        self._update_buttons()
        if path:
            self.refresh_packages()
        else:
            self.pkg_table.setRowCount(0)
            self.pkg_count_label.setText("0 packages")

    def _update_buttons(self):
        has_venv = self.current_venv is not None
        running = self.runner.is_running()
        self.btn_install.setEnabled(has_venv and not running)
        self.btn_refresh_pkgs.setEnabled(has_venv and not running)
        self.btn_upgrade.setEnabled(has_venv and not running)
        self.btn_uninstall.setEnabled(has_venv and not running)
        self.btn_freeze.setEnabled(has_venv and not running)
        self.btn_run_script.setEnabled(
            has_venv and self.current_script is not None and not running
        )
        self.btn_create.setEnabled(not running)

    # ---- Pip operations ----

    def install_package(self):
        if not self.current_venv or self.runner.is_running():
            return
        text = self.install_input.text().strip()
        if not text:
            return
        try:
            pkg_args = shlex.split(text)
        except ValueError as e:
            self.console.write_stderr(f"Parse error: {e}\n")
            return
        py = VenvManager.get_python(self.current_venv)
        if not py:
            self.console.write_stderr("No python found in selected venv\n")
            return
        self._last_op = "pip"
        self.runner.run(str(py), ["-m", "pip", "install", *pkg_args])
        self.install_input.clear()

    def refresh_packages(self):
        if not self.current_venv or self.query.is_running():
            return
        py = VenvManager.get_python(self.current_venv)
        if not py:
            return
        self.query.run(str(py), ["-m", "pip", "list", "--format=json"])

    def upgrade_selected(self):
        if not self.current_venv or self.runner.is_running():
            return
        pkg = self._selected_package()
        if not pkg:
            self.status.showMessage("Select a package to upgrade", 3000)
            return
        py = VenvManager.get_python(self.current_venv)
        if not py:
            return
        self._last_op = "pip"
        self.runner.run(str(py), ["-m", "pip", "install", "--upgrade", pkg])

    def uninstall_selected(self):
        if not self.current_venv or self.runner.is_running():
            return
        pkg = self._selected_package()
        if not pkg:
            self.status.showMessage("Select a package to uninstall", 3000)
            return
        reply = QMessageBox.question(
            self, "Uninstall package",
            f"Uninstall '{pkg}' from this venv?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        py = VenvManager.get_python(self.current_venv)
        if not py:
            return
        self._last_op = "pip"
        self.runner.run(str(py), ["-m", "pip", "uninstall", "-y", pkg])

    def freeze_packages(self):
        if not self.current_venv or self.query.is_running():
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save requirements.txt", "requirements.txt",
            "Text Files (*.txt);;All Files (*)",
        )
        if not path:
            return
        py = VenvManager.get_python(self.current_venv)
        if not py:
            return
        self._pending_freeze_path = path
        self.query.run(str(py), ["-m", "pip", "freeze"])

    def _selected_package(self) -> Optional[str]:
        row = self.pkg_table.currentRow()
        if row < 0:
            return None
        item = self.pkg_table.item(row, 0)
        return item.text() if item else None

    # ---- Script execution ----

    def set_script(self, path: str):
        p = Path(path)
        if not p.is_file():
            QMessageBox.warning(self, "Invalid file", f"Not a file: {path}")
            return
        self.current_script = p
        self.drop_zone.set_file(str(p))
        self._update_buttons()

    def browse_script(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Python script", str(Path.home()),
            "Python Files (*.py);;All Files (*)",
        )
        if path:
            self.set_script(path)

    def clear_script(self):
        self.current_script = None
        self.drop_zone.clear_file()
        self.args_input.clear()
        self._update_buttons()

    def run_script(self):
        if not self.current_venv or not self.current_script or self.runner.is_running():
            return
        py = VenvManager.get_python(self.current_venv)
        if not py:
            return
        try:
            extra_args = shlex.split(self.args_input.text().strip()) if self.args_input.text().strip() else []
        except ValueError as e:
            self.console.write_stderr(f"Args parse error: {e}\n")
            return
        cwd = str(self.current_script.parent) if self.cwd_check.isChecked() else None
        self._last_op = "script"
        self.runner.run(str(py), [str(self.current_script), *extra_args], cwd=cwd)

    # ---- Process slots ----

    def stop_process(self):
        if self.runner.is_running():
            self.console.write_system("Stopping process...")
            self.runner.stop()

    def _on_runner_started(self, cmd: str):
        self.console.write_command(cmd)
        self.btn_stop.setEnabled(True)
        self._update_buttons()
        self.status.showMessage("Running...")

    def _on_runner_finished(self, exit_code: int):
        if exit_code == 0:
            self.console.write_success("[exit 0]")
        else:
            self.console.write_stderr(f"[exit {exit_code}]\n")
        self.btn_stop.setEnabled(False)
        self.status.showMessage(f"Process finished (exit {exit_code})", 5000)

        op = self._last_op
        self._last_op = None
        pending_create = self._pending_venv_after_create
        self._pending_venv_after_create = None

        self._update_buttons()

        if op == "venv_create" and exit_code == 0 and pending_create is not None:
            QTimer.singleShot(200, lambda: self._set_current_venv(pending_create))
        elif op == "pip" and exit_code == 0 and self.current_venv:
            QTimer.singleShot(100, self.refresh_packages)

    def _on_query_completed(self, exit_code: int, out: str, err: str):
        # Freeze-to-file path
        if self._pending_freeze_path is not None:
            path = self._pending_freeze_path
            self._pending_freeze_path = None
            if exit_code == 0:
                try:
                    Path(path).write_text(out, encoding="utf-8")
                    self.console.write_success(f"Wrote {path}")
                    self.status.showMessage(f"Wrote {path}", 5000)
                except OSError as e:
                    self.console.write_stderr(f"Failed to write {path}: {e}\n")
            else:
                self.console.write_stderr(err or "pip freeze failed\n")
            return

        # Package list refresh
        if exit_code != 0:
            self.console.write_stderr(err or "Failed to list packages\n")
            self.pkg_table.setRowCount(0)
            self.pkg_count_label.setText("0 packages")
            return
        try:
            data = json.loads(out) if out.strip() else []
        except json.JSONDecodeError as e:
            self.console.write_stderr(f"Failed to parse package list: {e}\n")
            return

        self.pkg_table.setRowCount(0)
        self.pkg_table.setRowCount(len(data))
        for i, pkg in enumerate(data):
            name_item = QTableWidgetItem(pkg.get("name", ""))
            ver_item = QTableWidgetItem(pkg.get("version", ""))
            self.pkg_table.setItem(i, 0, name_item)
            self.pkg_table.setItem(i, 1, ver_item)
        self.pkg_count_label.setText(f"{len(data)} package(s)")

    # ---- Lifecycle ----

    def closeEvent(self, event):
        if self.runner.is_running():
            reply = QMessageBox.question(
                self, "Process running",
                "A process is still running. Stop it and exit?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.runner.stop()
        event.accept()


# =============================================================================
# Entry point
# =============================================================================

def main():
    # Windows: tell the shell this is a distinct app so the taskbar uses our
    # icon rather than the generic Python launcher icon.
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                f"{ORG_NAME}.{APP_NAME}"
            )
        except Exception:
            pass

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setStyle("Fusion")
    app.setStyleSheet(DARK_STYLESHEET)

    icon = create_icon()
    if icon:
        app.setWindowIcon(icon)

    splash = create_splash()
    if splash:
        splash.show()
        for msg in ["Starting...", "Discovering venvs...", "Loading..."]:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    window = MainWindow()
    if icon:
        window.setWindowIcon(icon)
    window.show()
    if splash:
        splash.finish(window)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
